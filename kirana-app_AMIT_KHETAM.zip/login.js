window.loginUser = function() {
  const userType = document.querySelector('input[name="userType"]:checked').value;

  // Customer → लगेच redirect
  if(userType === "customer") {
    window.location.href = "index.html"; 
    return;
  }

  // Shopkeeper login
  const email = document.getElementById("loginEmail").value;
  const password = document.getElementById("loginPassword").value;

  const shopkeeperEmail = "shop@amitstore.com";
  const shopkeeperPassword = "123456";

  if(email === shopkeeperEmail && password === shopkeeperPassword) {
    alert("✅ Shopkeeper Login Success!");
    window.location.href = "admin.html";
  } else {
    alert("❌ Wrong Email or Password!");
  }
}