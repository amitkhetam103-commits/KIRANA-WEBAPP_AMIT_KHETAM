import { initializeApp } from "https://www.gstatic.com/firebasejs/10.7.1/firebase-app.js";
import { getFirestore, collection, onSnapshot, updateDoc, doc } from "https://www.gstatic.com/firebasejs/10.7.1/firebase-firestore.js";

// Firebase config (same as your store)
const firebaseConfig = {
  apiKey: "AIzaSyB-shDIQwFBuRgEFw2l2V29o1Su9fRyPQQ",
  authDomain: "amit-kirana-store.firebaseapp.com",
  projectId: "amit-kirana-store",
  storageBucket: "amit-kirana-store.firebasestorage.app",
  messagingSenderId: "1088446710195",
  appId: "1:1088446710195:web:5d1704f3d0c8c529458bc6"
};

const app = initializeApp(firebaseConfig);
const db = getFirestore(app);

const ordersTableBody = document.querySelector("#ordersTable tbody");

const ordersCollection = collection(db, "orders");

// Live listener – Firestore मधून नवीन orders
onSnapshot(ordersCollection, (snapshot) => {
  ordersTableBody.innerHTML = ""; // reset table

  snapshot.forEach((docSnap) => {
    const order = docSnap.data();
    const tr = document.createElement("tr");

    tr.innerHTML = `
      <td>${docSnap.id}</td>
      <td>${order.items.map(i => i.name).join(", ")}</td>
      <td>₹${order.total}</td>
      <td>${order.userName}</td>
      <td>${order.userMobile}</td>
      <td>${order.userAddress}</td>
      <td>${order.payment}</td>
      <td>${order.status}</td>
      <td>
        <button onclick="markCompleted('${docSnap.id}')">Complete</button>
      </td>
    `;

    ordersTableBody.appendChild(tr);
  });
});

// Mark order as completed
window.markCompleted = async function(id) {
  const orderDoc = doc(db, "orders", id);
  await updateDoc(orderDoc, { status: "completed" });
  alert("Order marked as completed!");
};