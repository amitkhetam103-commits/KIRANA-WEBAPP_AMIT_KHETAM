// Firebase config
const firebaseConfig = {
  apiKey: "AIzaSyB-shDIQwFBuRgEFw2l2V29o1Su9fRyPQQ",
  authDomain: "amit-kirana-store.firebaseapp.com",
  projectId: "amit-kirana-store",
  storageBucket: "amit-kirana-store.firebasestorage.app",
  messagingSenderId: "1088446710195",
  appId: "1:1088446710195:web:5d1704f3d0c8c529458bc6"
};

// Initialize
firebase.initializeApp(firebaseConfig);
const db = firebase.firestore();

// Cart
let cart = [];

function updateCartUI() {
  const cartCount = cart.reduce((sum, i) => sum + i.qty, 0);
  const cartTotalPrice = cart.reduce((sum, i) => sum + i.qty*i.price, 0);
  document.getElementById('cartCount').innerText = cartCount;
  document.getElementById('cartTotal').innerText = `🛒 ${cartCount} Items | ₹${cartTotalPrice}`;
}

// Products
document.querySelectorAll('.product-card').forEach(card=>{
  const name = card.dataset.name;
  const price = parseInt(card.dataset.price);
  const qtySpan = card.querySelector('.qty-num');
  const plusBtn = card.querySelector('.plus');
  const minusBtn = card.querySelector('.minus');

  plusBtn.addEventListener('click', ()=>{
    let item = cart.find(i=>i.name===name);
    if(item){ item.qty++; } else { cart.push({name, price, qty:1}); }
    qtySpan.innerText = cart.find(i=>i.name===name).qty;
    updateCartUI();
  });

  minusBtn.addEventListener('click', ()=>{
    let item = cart.find(i=>i.name===name);
    if(item){ 
      item.qty--; 
      if(item.qty<=0){ cart = cart.filter(i=>i.name!==name); qtySpan.innerText = 0;} 
      else { qtySpan.innerText = item.qty;} 
    }
    updateCartUI();
  });
});

// Place Order
document.getElementById('orderBtn').addEventListener('click', ()=>{
  if(cart.length===0){ alert("Cart empty!"); return; }

  const name = document.getElementById('userName').value.trim();
  const mobile = document.getElementById('userMobile').value.trim();
  const address = document.getElementById('userAddress').value.trim();
  const payment = document.querySelector('input[name="payment"]:checked').value;

  if(!name || !mobile || !address){ alert("Fill all details!"); return; }

  const orderData = {customerName:name, mobile, address, paymentMethod:payment, items:cart, time:new Date()};

  // Firebase save
  db.collection("orders").add(orderData)
    .then(()=> {
      alert("Order placed successfully!");
      cart=[]; updateCartUI();
      document.querySelectorAll('.qty-num').forEach(s=>s.innerText=0);
      document.getElementById('userName').value='';
      document.getElementById('userMobile').value='';
      document.getElementById('userAddress').value='';
    })
    .catch(err=> alert("Firebase Error: "+err));
});